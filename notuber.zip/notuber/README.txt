All aspects have been implemented correctly. The google map, the XMLHTTP POST, the Haversine Formula etc.
This was an independent project
I have spent 3.5 hours completing this assignment